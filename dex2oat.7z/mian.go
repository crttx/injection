package main

import (
	"fmt"
	"log"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// dataDir 是 Android 应用数据的根目录
const dataDir = "/data/data"

// --- 新增: 共享状态 ---
var (
	// 
	workerStatuses []string
	// 
	statusMutex sync.Mutex
)

/**
 * worker 
 * @param id
 * @param jobs
 * @param wg
 * @param completed
 */
func worker(id int, jobs <-chan string, wg *sync.WaitGroup, completed *atomic.Int32) {
	for pkgName := range jobs {
		// --- 
		statusMutex.Lock()
		workerStatuses[id] = pkgName // 
		statusMutex.Unlock()

		// 
		cmd := exec.Command("cmd", "package", "compile", "-m", "everything", pkgName)
		output, err := cmd.CombinedOutput()

		// --- 
		statusMutex.Lock()
		workerStatuses[id] = "" // 
		statusMutex.Unlock()

		// 
		completed.Add(1)

		if err != nil {
			// 
			// 
			// 
			fmt.Fprintf(os.Stderr, "\n[Worker %d] 编译 %s 失败: %v\n输出: %s\n", id, pkgName, err, strings.TrimSpace(string(output)))
		}

		wg.Done()
	}
}

/**
 * buildProgressBarString 
 * @param current
 * @param total
 * @return string
 */
func buildProgressBarString(current int32, total int) string {
	if total == 0 {
		return "[进度 0/0] [ 0.0%]"
	}

	percentage := float64(current) / float64(total)
	barWidth := 40 // 

	filledWidth := int(percentage * float64(barWidth))

	var bar strings.Builder
	bar.WriteString("[")
	bar.WriteString(strings.Repeat("=", filledWidth))
	if filledWidth < barWidth {
		bar.WriteString(">")
		bar.WriteString(strings.Repeat(" ", barWidth-filledWidth-1))
	}
	bar.WriteString("]")

	return fmt.Sprintf("[进度 %d/%d] %s %.1f%%", current, total, bar.String(), percentage*100.0)
}

/**
 * * @param current
 * @param total
 * @param statuses
 */
func drawTUI(current int32, total int, statuses []string) {
	numWorkers := len(statuses) - 1 // 

	// 1. 
	fmt.Printf("\r")

	// 2. 
	// \033[K 
	barString := buildProgressBarString(current, total)
	fmt.Printf("%s\033[K\n", barString)

	// 3. 
	for i := 1; i <= numWorkers; i++ {
		status := statuses[i]
		if status == "" {
			status = "空闲"
		}
		// 
		// 
		fmt.Printf("  Worker %-2d: %-45s\033[K\n", i, status)
	}

	// 4. 
	// 
	fmt.Printf("\033[%dA", numWorkers+1)
}

/**
 * * @param current
 * @param total
 * @param numWorkers
 */
func drawFinalTUI(current int32, total int, numWorkers int) {
	// 1. 
	fmt.Printf("\r")

	// 2. 
	barString := buildProgressBarString(current, total)
	fmt.Printf("%s\033[K\n", barString)

	// 3. 
	for i := 1; i <= numWorkers; i++ {
		fmt.Printf("  Worker %-2d: %-45s\033[K\n", i, "完成")
	}

	// 4. 
}

/**
 * * @param done
 * @param reporterWg
 * @param completed
 * @param total
 * @param numWorkers
 */
func progressReporter(done chan bool, reporterWg *sync.WaitGroup, completed *atomic.Int32, total int, numWorkers int) {
	defer reporterWg.Done()

	ticker := time.NewTicker(200 * time.Millisecond) // 
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			// 
			current := completed.Load()
			
			// 
			statusMutex.Lock()
			snapshot := make([]string, numWorkers+1)
			copy(snapshot, workerStatuses)
			statusMutex.Unlock()
			
			drawTUI(current, total, snapshot)

		case <-done:
			// 
			current := completed.Load()
			drawFinalTUI(current, total, numWorkers)
			return
		}
	}
}

func main() {
	// 
	log.SetFlags(0)
	log.Println("--- Android 全包 everything 编译工具 (多行TUI版) ---")

	// 1. 
	if os.Getuid() != 0 {
		log.Fatalln("错误: 本工具需要 root 权限 (uid 0) 才能运行。请使用 'su'。")
	}

	// 2. 
	log.Println("正在扫描 /data/data 统计应用包...")
	entries, err := os.ReadDir(dataDir)
	if err != nil {
		log.Fatalf("无法读取 %s 目录: %v. (请确保已 'su')\n", dataDir, err)
	}

	var packagesToCompile []string
	for _, entry := range entries {
		if entry.IsDir() && strings.Contains(entry.Name(), ".") {
			pkgName := entry.Name()
			if pkgName == "com.android.shell" || pkgName == "android" {
				continue
			}
			packagesToCompile = append(packagesToCompile, pkgName)
		}
	}

	totalPackages := len(packagesToCompile)
	if totalPackages == 0 {
		log.Fatalf("在 %s 未找到任何应用包。", dataDir)
	}
	log.Printf("--- 统计完成: 发现 %d 个应用包需要编译 ---", totalPackages)

	// 3. 
	numWorkers := runtime.NumCPU() * 2
	if numWorkers < 1 {
		numWorkers = 1
	}
	log.Printf("--- 启动 %d 个并发编译线程 ---", numWorkers)

	// 4. 
	// 
	// 
	workerStatuses = make([]string, numWorkers+1) // 

	// 5. 
	jobs := make(chan string, 100)
	var workerWg sync.WaitGroup
	var reporterWg sync.WaitGroup
	var completedCount atomic.Int32
	done := make(chan bool)

	// 6. 
	reporterWg.Add(1)
	go progressReporter(done, &reporterWg, &completedCount, totalPackages, numWorkers)

	// 7. 
	for w := 1; w <= numWorkers; w++ {
		// 
		go worker(w, jobs, &workerWg, &completedCount)
	}

	// 8. 
	log.Println("--- 开始分发编译任务 ---")
	for _, pkgName := range packagesToCompile {
		workerWg.Add(1)
		jobs <- pkgName
	}
	close(jobs)

	// 9. 
	workerWg.Wait()

	// 10. 
	close(done)
	reporterWg.Wait()

	log.Println("--- 所有编译任务已完成 ---")
}
